import React, { useState } from 'react';
import "./styles.css";

export default function App() {
  const [count, setCount] = useState(0);
  const [age, setAge] = useState(0);
  const [fruit, setFruit] = useState('банан');
  const [todos, setTodos] = useState([{ text: 'Изучить хуки' }]);

function randomise (list) {
return list[Math.floor((Math.random()*list.length))];
}

function Notes() {
const [todos, setTodos] = useState([{ text: 'Изучить хуки' }]);
var inp
}

var list=['банан', 'яблоко', 'апельсин', 'груша', 'киви'];
  return (
    <div className="Color">
      <p>Вы нажали {count} раз</p>
      <button onClick={() => setCount(count + 1)}>
        Нажми на меня
      </button>  

      <p>Возраст {age}</p>
      <button onClick={() => setAge(age + 1)}>
        Возраст
      </button>

      <p>Вы выбрали {fruit}</p>
      <button onClick={() => setFruit(randomise(list))}>
        Фрукт
      </button>

      <p>Список todo</p>
      <ul>
        {todos.map(item => (<li>{item.text}</li>))}
      </ul>
      <textarea
      onChange={(e) => { inp = e.target.value }}/>
      <button onClick={() => setTodos(todos.concat({ text: inp }))}>
        Добавить
      </button>
    </div>
  )
}